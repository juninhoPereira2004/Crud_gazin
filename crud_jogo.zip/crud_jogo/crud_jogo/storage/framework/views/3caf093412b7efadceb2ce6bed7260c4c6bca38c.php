

<?php $__env->startSection('title', 'Criação'); ?>

<?php $__env->startSection('content'); ?>

        
<div class="container mt-5">
  <h1>Editar o Jogo</h1>
  <hr>
  <br>
  <form action="<?php echo e(route('jogos-update', ['id'=>$jogos->id])); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
    <div class="form-group">
      <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" class="form-control" name="nome" value="<?php echo e($jogos->nome); ?>" placeholder="Digite um Nome de Jogo...">
      </div>

      <br>

      <div class="form-group">
        <label for="categoria">Categoria</label>
        <input type="text" class="form-control" name="categoria" value="<?php echo e($jogos->categoria); ?>" placeholder="Digite uma Categoria para o Jogo...">
      </div>

      <br>

      <div class="form-group">
        <label for="ano_criacao">Ano De Criação</label>
        <input type="text" class="form-control" name="ano_criacao" value="<?php echo e($jogos->ano_criacao); ?>" placeholder="Ano De Criação...">
      </div>

      <br>

      <div class="form-group">
        <label for="valor">Valor</label>
        <input type="number" class="form-control" name="valor" value="<?php echo e($jogos->valor); ?>" placeholder="Digite um Valor...">
      </div>

      <br>

      <div class="form-group">
        <input type="submit" name="submit" value="Atualizar" class="btn btn-success" value="cadastrar">
      </div>
    </div>
  </form>
</div>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud_jogo\crud_jogo\resources\views/jogos/edit.blade.php ENDPATH**/ ?>