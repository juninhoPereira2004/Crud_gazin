<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Testando routes com views <?php echo e($nome); ?></h1>
    <p>id: <?php echo e($id); ?></p>
    <p>Nome: <?php echo e($nome); ?></p>
    <a href="<?php echo e(route('home-index')); ?>">Clique aqui</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\crud_jogo\crud_jogo\resources\views/jogos.blade.php ENDPATH**/ ?>